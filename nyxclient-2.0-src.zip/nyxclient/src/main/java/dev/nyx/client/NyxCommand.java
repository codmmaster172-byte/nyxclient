package dev.nyx.client;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;

public class NyxCommand extends CommandBase {
    @Override public String getCommandName() { return "nyx"; }
    @Override public String getCommandUsage(ICommandSender s) { return "/nyx <list [prefix]|get k|set k v|ka|scaffold|save>"; }
    @Override public int getRequiredPermissionLevel() { return 0; }
    @Override public boolean canCommandSenderUseCommand(ICommandSender s) { return true; }

    @Override
    public void processCommand(ICommandSender sender, String[] a) throws CommandException {
        if (a.length == 0) { NyxClient.msg(getCommandUsage(sender)); return; }
        String c = a[0].toLowerCase();
        if (c.equals("list")) {
            String pre = a.length > 1 ? a[1] : "";
            for (String k : Settings.keys()) if (k.startsWith(pre)) NyxClient.msg(k + " = " + Settings.get(k));
        } else if (c.equals("get") && a.length > 1) {
            NyxClient.msg(a[1] + " = " + Settings.get(a[1]));
        } else if (c.equals("set") && a.length > 2) {
            StringBuilder v = new StringBuilder(a[2]);
            for (int i = 3; i < a.length; i++) v.append(' ').append(a[i]);
            if (Settings.set(a[1], v.toString())) { Settings.save(); NyxClient.msg(a[1] + " = " + Settings.get(a[1])); }
            else NyxClient.msg("bad key or value");
        } else if (c.equals("ka")) {
            NyxClient.KA.enabled = !NyxClient.KA.enabled;
            NyxClient.msg("KillAura " + (NyxClient.KA.enabled ? "on" : "off"));
        } else if (c.equals("scaffold")) {
            NyxClient.SC.enabled = !NyxClient.SC.enabled;
            NyxClient.msg("Scaffold " + (NyxClient.SC.enabled ? "on" : "off"));
        } else if (c.equals("save")) {
            Settings.save();
            NyxClient.msg("saved");
        } else {
            NyxClient.msg(getCommandUsage(sender));
        }
    }
}
