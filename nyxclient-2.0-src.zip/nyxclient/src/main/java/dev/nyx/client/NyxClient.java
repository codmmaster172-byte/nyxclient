package dev.nyx.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import net.minecraftforge.fml.relauncher.Side;
import org.lwjgl.input.Keyboard;

@Mod(modid = "nyxclient", name = "NyxClient", version = "2.0", clientSideOnly = true, acceptedMinecraftVersions = "[1.8.9]")
public class NyxClient {
    public static final KillAura KA = new KillAura();
    public static final Scaffold SC = new Scaffold();
    private final KeyBinding kKill = new KeyBinding("KillAura", Keyboard.KEY_R, "NyxClient");
    private final KeyBinding kScaf = new KeyBinding("Scaffold", Keyboard.KEY_G, "NyxClient");

    public static void msg(String s) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer != null) mc.thePlayer.addChatMessage(new ChatComponentText("[Nyx] " + s));
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        ClientRegistry.registerKeyBinding(kKill);
        ClientRegistry.registerKeyBinding(kScaf);
        ClientCommandHandler.instance.registerCommand(new NyxCommand());
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onConnect(FMLNetworkEvent.ClientConnectedToServerEvent ev) {
        RotationManager.reset();
        try {
            ev.manager.channel().pipeline().addBefore("packet_handler", "nyx_rewriter", new PacketRewriter());
        } catch (Throwable ignored) {}
    }

    @SubscribeEvent
    public void onDisconnect(FMLNetworkEvent.ClientDisconnectionFromServerEvent ev) {
        RotationManager.reset();
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent ev) {
        if (ev.phase != TickEvent.Phase.START) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.theWorld == null) { RotationManager.reset(); return; }

        while (kKill.isPressed()) { KA.enabled = !KA.enabled; msg("KillAura " + (KA.enabled ? "on" : "off")); }
        while (kScaf.isPressed()) { SC.enabled = !SC.enabled; msg("Scaffold " + (SC.enabled ? "on" : "off")); }

        boolean busy = SC.tick(mc);
        KA.tick(mc, busy);
        RotationManager.tick(mc.thePlayer);
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent ev) {
        Minecraft mc = Minecraft.getMinecraft();
        if (ev.side != Side.CLIENT || ev.player != mc.thePlayer) return;
        EntityPlayerSP p = (EntityPlayerSP) ev.player;
        if (ev.phase == TickEvent.Phase.START) RotationManager.begin(p);
        else RotationManager.end(p);
    }

    @SubscribeEvent
    public void onInput(InputUpdateEvent ev) {
        RotationManager.fixInput(ev.movementInput, Minecraft.getMinecraft().thePlayer.isSneaking());
    }
}
