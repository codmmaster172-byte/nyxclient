package dev.nyx.client;

import net.minecraft.client.Minecraft;
import java.io.*;
import java.util.*;

public class Settings {
    private static final Map<String, Object> M = new LinkedHashMap<String, Object>();
    private static void d(String k, Object v) { M.put(k, v); }

    static {
        // KillAura
        d("ka.range", 3.0);
        d("ka.fov", 120.0);
        d("ka.cpsMin", 9.0);
        d("ka.cpsMax", 13.0);
        d("ka.hurtTime", 10.0);        // only attack when target.hurtTime <= this (10 = no limit)
        d("ka.rayCast", true);         // only swing when the sent rotation actually hits the hitbox
        d("ka.throughWalls", false);
        d("ka.invisible", false);
        d("ka.sticky", true);          // keep current target while valid
        d("ka.sort", "distance");      // distance | health | angle
        d("ka.sprintReset", true);
        d("ka.autoblock", "packet");   // off | packet
        d("ka.silent", true);
        d("ka.turnMin", 22.0);
        d("ka.turnMax", 42.0);
        // Rotations
        d("rot.moveFix", true);
        d("rot.gcd", true);
        d("rot.jitter", 0.35);
        d("rot.returnSpeed", 30.0);
        // Team / targets
        d("team.scoreboard", true);
        d("team.nameColor", true);
        d("team.armorColor", true);
        d("team.antiBot", true);
        d("team.botTicks", 15.0);
        d("team.friends", "");
        // Scaffold
        d("sc.autoSwitch", true);
        d("sc.silent", true);
        d("sc.turnMin", 20.0);
        d("sc.turnMax", 38.0);
        d("sc.delayMin", 1.0);
        d("sc.delayMax", 2.0);
        d("sc.reach", 4.5);
        d("sc.swing", true);
        load();
    }

    public static double num(String k) { return ((Number) M.get(k)).doubleValue(); }
    public static boolean bool(String k) { return (Boolean) M.get(k); }
    public static String str(String k) { return String.valueOf(M.get(k)); }
    public static Object get(String k) { return M.get(k); }
    public static Set<String> keys() { return M.keySet(); }

    public static boolean set(String k, String v) {
        Object o = M.get(k);
        if (o == null) return false;
        try {
            if (o instanceof Boolean) M.put(k, Boolean.parseBoolean(v));
            else if (o instanceof Double) M.put(k, Double.parseDouble(v));
            else M.put(k, v);
        } catch (Exception e) { return false; }
        return true;
    }

    private static File file() {
        File dir = new File(Minecraft.getMinecraft().mcDataDir, "config");
        dir.mkdirs();
        return new File(dir, "nyxclient.properties");
    }

    public static void save() {
        try {
            Properties p = new Properties();
            for (Map.Entry<String, Object> e : M.entrySet()) p.setProperty(e.getKey(), String.valueOf(e.getValue()));
            FileOutputStream out = new FileOutputStream(file());
            p.store(out, "NyxClient");
            out.close();
        } catch (Exception ignored) {}
    }

    private static void load() {
        try {
            File f = file();
            if (!f.exists()) return;
            Properties p = new Properties();
            FileInputStream in = new FileInputStream(f);
            p.load(in);
            in.close();
            for (String k : p.stringPropertyNames()) set(k, p.getProperty(k));
        } catch (Exception ignored) {}
    }
}
